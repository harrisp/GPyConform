"""
Initialize the gpyconform package, applying patches for adding the Conformal prediction strategies.

Set GPYCONFORM_AUTOPATCH=1 to patch on import; otherwise full CP patches automatically when 
ExactGPCP is instantiated.
"""

__version__ = '0.1.1'

import os
from .exact_prediction_strategies_cp import apply_patches, is_patched

if os.getenv("GPYCONFORM_AUTOPATCH", "") == "1":
    apply_patches()

from .exact_gpcp import ExactGPCP
from .gpricp import GPRICPWrapper, InductiveConformalRegressor
from .prediction_intervals import PredictionIntervals

__all__ = ['__version__', 
           'ExactGPCP', 
           'GPRICPWrapper', 
           'InductiveConformalRegressor', 
           'PredictionIntervals',
           'apply_patches',
           'is_patched']